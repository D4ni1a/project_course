﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    static class Program
    {
        public static Maintenance Mass = new Maintenance();
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
    class Maintenance
    {
        double[] a; //Массив чисел с плавающей запятой
        public int len; //Переменная для размера массива
        public Maintenance()
        {
            len = 6;
            a = new double[6];
        }
        public double this[int index] //Индексатор для добавления и извлечения элементов
        {
            get
            {
                return a[index]; //Извлечение
            }
            set
            {
                a[index] = value; //Добавление
            }
        }
        public string Times(string n, string m, string b)
        {
            int c1 = System.Convert.ToInt32(n);// Количество СВТ
            int c2 = System.Convert.ToInt32(m); //Количество рабочих
            string check = b;
            double time_label =0;

            foreach (char x in check)
            {
                time_label += a[System.Convert.ToInt32(x)-48];
            }
            time_label = (time_label * c1) / c2;

            return System.Convert.ToString(time_label);
        }
    }
}
